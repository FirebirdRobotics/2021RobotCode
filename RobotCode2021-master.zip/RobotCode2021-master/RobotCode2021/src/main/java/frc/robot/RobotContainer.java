// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

import edu.wpi.first.wpilibj.GenericHID;
import edu.wpi.first.wpilibj.XboxController;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj2.command.RunCommand;
import frc.robot.commands.DriveForward;
import frc.robot.subsystems.Drivetrain;
import edu.wpi.first.wpilibj.GenericHID.Hand;

/**
 * This class is where the bulk of the robot should be declared. Since Command-based is a
 * "declarative" paradigm, very little robot logic should actually be handled in the {@link Robot}
 * periodic methods (other than the scheduler calls). Instead, the structure of the robot (including
 * subsystems, commands, and button mappings) should be declared here.
 */
public class RobotContainer {
  // The robot's subsystems and commands are defined here...

  public static final Drivetrain m_drivetrain = new Drivetrain();

  final static XboxController m_driverController = new XboxController(0);

  public double m_speedy = 0.2; // adds/subtracts speed from robot
  public boolean m_swappy = false; // tells whether to invert drivetrain

  SendableChooser<DriveForward> m_chooser = new SendableChooser<>();


  /** The container for the robot. Contains subsystems, OI devices, and commands. */
  public RobotContainer() {

    configureButtonBindings();
    // Configure the button bindings
    m_drivetrain.setDefaultCommand(new RunCommand( () -> 
    m_drivetrain.arcadeDrive(-m_driverController.getY(Hand.kLeft) * m_speedy,
    m_driverController.getX(Hand.kRight) * m_speedy)));
    
  }

  /**
   * Use this method to define your button->command mappings. Buttons can be created by
   * instantiating a {@link GenericHID} or one of its subclasses ({@link
   * edu.wpi.first.wpilibj.Joystick} or {@link XboxController}), and then passing it to a {@link
   * edu.wpi.first.wpilibj2.command.button.JoystickButton}.
   */
  private void configureButtonBindings() {

  }

  /**
   * Use this to pass the autonomous command to the main {@link Robot} class.
   *
   * @return the command to run in autonomous
   */
  
  public DriveForward getAutonomousCommand() {
    // An ExampleCommand will run in autonomous
    return m_chooser.getSelected();
    
  }

}