// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.subsystems;

import edu.wpi.first.wpilibj.SpeedControllerGroup;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants.DriveConstants;

//import com.ctre.phoenix.motorcontrol.SupplyCurrentLimitConfiguration;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonFX;

public class Drivetrain extends SubsystemBase {
  /** Creates a new Drivetrain. */
  private final WPI_TalonFX m_leftMaster, m_rightMaster, m_leftSlave, m_rightSlave;

  //private final SupplyCurrentLimitConfiguration m_currentLimitConfig;

  private final DifferentialDrive m_diffDrive;

  private final SpeedControllerGroup m_right;
  private final SpeedControllerGroup m_left;

  //private boolean dtIsInverted;

  public Drivetrain() {
    m_leftMaster = new WPI_TalonFX(DriveConstants.dtFrontLeftPort);
    m_rightMaster = new WPI_TalonFX(DriveConstants.dtFrontRightPort);
    m_leftSlave = new WPI_TalonFX(DriveConstants.dtBackLeftPort);
    m_rightSlave = new WPI_TalonFX(DriveConstants.dtBackRightPort);
/*
    m_currentLimitConfig = new SupplyCurrentLimitConfiguration(
      DriveConstants.kCurrentLimitingEnabled, DriveConstants.kPeakCurrentAmps,
      DriveConstants.kContCurrentAmps, DriveConstants.kPeakTimeMs);
*/
        m_left = new SpeedControllerGroup(m_leftMaster, m_leftSlave);
        m_right = new SpeedControllerGroup(m_rightMaster, m_rightSlave);

    m_diffDrive = new DifferentialDrive(m_left, m_right);

    m_leftSlave.follow(m_leftMaster);
    m_rightSlave.follow(m_rightMaster);

    m_left.setInverted(true); // CHANGE THESE UNTIL ROBOT DRIVES FORWARD
    m_right.setInverted(false); // CHANGE THESE UNTIL ROBOT DRIVES FORWARD

    //dtIsInverted = false;

    // flip so that motor output and sensor velocity are same polarity
    m_leftMaster.setSensorPhase(false);
    m_rightMaster.setSensorPhase(false);
    m_leftSlave.setSensorPhase(false);
    m_rightSlave.setSensorPhase(false);

    // set mode of motors
    

    // diffdrive assumes by default that right side must be negative- change to false for master/slave config
    m_diffDrive.setRightSideInverted(false); // DO NOT CHANGE THIS

    // deadband: motors wont move if speed of motors is within deadband
    m_diffDrive.setDeadband(DriveConstants.kDeadband);

  }
 
  public void arcadeDrive(final double forward, final double turn) {
    m_diffDrive.arcadeDrive(forward * DriveConstants.kDriveSpeed, turn * DriveConstants.kTurnSpeed, true);
  }

  // CURVATURE DRIVE = 2 STICK + QUICK TURN BUTTON
  public void curvatureDrive(final double forward, final double turn, final boolean quickTurn) {
    m_diffDrive.curvatureDrive(forward * DriveConstants.kDriveSpeed, turn * DriveConstants.kTurnSpeed, quickTurn);
  }


  @Override
  public void periodic() {
    // This method will be called once per scheduler run
  }

  
}
